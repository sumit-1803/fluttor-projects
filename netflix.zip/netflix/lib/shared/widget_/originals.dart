import 'package:flutter/material.dart';

class Originals extends StatelessWidget {
  const Originals({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 15, top: 10, bottom: 10),
          child: Text(
            'Netflix Original',
            style: TextStyle(
                color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(
          height: 5,
        ),
        Container(
          color: Colors.transparent,
          width: double.infinity,
          height: 300,
          child: ListView(
            padding: const EdgeInsets.only(right: 10, left: 10),
            scrollDirection: Axis.horizontal,
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (1).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 1, left: 1),
                child: Image.asset('assets/orignal (2).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (3).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (4).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (5).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (6).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (7).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (8).jpeg'),
              ),
            ],
          ),
        )
      ],
    );
  }
}
