import 'package:flutter/material.dart';

class MYlist extends StatelessWidget {
  const MYlist({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 15, top: 10, bottom: 10),
          child: Text(
            'My List',
            style: TextStyle(
                color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(
          height: 5,
        ),
        Container(
          color: Colors.transparent,
          width: double.infinity,
          height: 200,
          child: ListView(
            padding: const EdgeInsets.only(right: 10, left: 10),
            scrollDirection: Axis.horizontal,
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/stranger_things.jpg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/violet_evergarden.jpg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (4).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (3).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/orignal (8).jpeg'),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10, left: 10),
                child: Image.asset('assets/sintel.jpg'),
              ),
            ],
          ),
        )
      ],
    );
  }
}
