import 'package:flutter/material.dart';

class Preview extends StatelessWidget {
  const Preview({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 15),
          child: Text(
            'Previews',
            style: TextStyle(
                color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(
          height: 5,
        ),
        Container(
          color: Colors.transparent,
          width: double.infinity,
          height: 125,
          child: ListView(
            padding: const EdgeInsets.only(right: 10, left: 10),
            scrollDirection: Axis.horizontal,
            children: const [
              Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/dogs.jpg'),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/witcher.jpg'),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/stranger_things.jpg'),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/thirteen_reasons.jpg'),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/umbrella_academy.jpg'),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 10, left: 10),
                child: CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/violet_evergarden.jpg'),
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
