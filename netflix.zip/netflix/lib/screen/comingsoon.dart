
import 'package:flutter/material.dart';

class ComingSoon extends StatelessWidget {
  const ComingSoon({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          leading: Image.asset(
            "assets/netflix_logo0.png",
          ),
          title: const Text(
            'Profiles & More',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.black,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 20,
            ),

            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 70,
              child: Padding(
                padding: const EdgeInsets.only(left: 10),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: const [
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: SquareAvatar(
                        size: 70,
                        backgroundImage:
                            AssetImage('assets/profile_pic-1.webp'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: SquareAvatar(
                        size: 70,
                        backgroundImage:
                            AssetImage('assets/profile_pic-2.webp'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: SquareAvatar(
                        size: 70,
                        backgroundImage:
                            AssetImage('assets/profile_pic-3.webp'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: SquareAvatar(
                        size: 70,
                        backgroundImage:
                            AssetImage('assets/profile_pic-4.webp'),
                      ),
                    ),
                    SizedBox(width: 10),
                    Padding(
                      padding: EdgeInsets.all(2.0),
                      child: SquareAvatar(
                        size: 70,
                        backgroundImage:
                            AssetImage('assets/profile_pic-5.webp'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(
              width: 400,
              height: 50,
              child: Row(
                children: [
                  Text(
                    'Nobita',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 37,
                  ),
                  Text(
                    'Cool',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 33,
                  ),
                  Text(
                    'Bunny',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 33,
                  ),
                  Text(
                    'Perry',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    width: 40,
                  ),
                  Text(
                    'Ash',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),

            const SizedBox(
              width: 400,
              height: 50,
              child: Padding(
                padding: EdgeInsets.only(bottom: 30),
                child: Row(
                  children: [
                    SizedBox(
                      width: 106,
                    ),
                    Icon(
                      Icons.lock_outline,
                      color: Colors.grey,
                    ),
                    SizedBox(
                      width: 140,
                    ),
                    Icon(
                      Icons.lock_outline,
                      color: Colors.grey,
                    ),
                    SizedBox(
                      width: 60,
                    ),
                    Icon(
                      Icons.lock_outline,
                      color: Colors.grey,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              width: 400,
              height: 50,
              child: Center(
                child: Padding(
                  padding: EdgeInsets.only(left: 90),
                  child: Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(right: 0),
                        child: Icon(
                          Icons.edit_outlined,
                          color: Colors.grey,
                          size: 35,
                        ),
                      ),
                      Text(
                        'Manage Profiles',
                        style: TextStyle(color: Colors.grey, fontSize: 24),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
            Container(
              width: 400,
              height: 50,
              color: const Color.fromARGB(255, 51, 51, 51),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 0),
                    child: Icon(
                      Icons.notification_add,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                      width:
                          10), 
                  Text(
                    'Notification',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 80),
                    child: Icon(
                      Icons.slideshow,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            
            Container(
              width: 400,
              height: 50,
              color: const Color.fromARGB(255, 51, 51, 51),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 0),
                    child: Icon(
                      Icons.list,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                      width:
                          10), 
                  Text(
                    'My List',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),

                  Padding(
                    padding: EdgeInsets.only(left: 120),
                    child: Icon(
                      Icons.slideshow,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // app setting
            Container(
              width: 400,
              height: 50,
              color: const Color.fromARGB(255, 51, 51, 51),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 0),
                    child: Icon(
                      Icons.settings,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                      width:
                          10), 
                  Text(
                    'App settings',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 70),
                    child: Icon(
                      Icons.slideshow,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            //account

            Container(
              width: 400,
              height: 50,
              color: const Color.fromARGB(255, 51, 51, 51),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 0),
                    child: Icon(
                      Icons.account_box,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                      width:
                          10), 
                  Text(
                    'Account',
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 110),
                    child: Icon(
                      Icons.slideshow,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
           Container(
              width: 400,
              height: 50,
              color: const Color.fromARGB(255, 51, 51, 51),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 0),
                    child: Icon(
                      Icons.help,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                      width:
                          10), 
                  Text(
                    'Help',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 145),
                    child: Icon(
                      Icons.slideshow,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const SizedBox(
              width: 400,
              height: 50,
              child:  Padding(
                padding: EdgeInsets.only(left: 145, right: 110, top: 10),
                child: Text(
                  "Sign Out",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SquareAvatar extends StatelessWidget {
  final double size;
  final ImageProvider<Object> backgroundImage;

  const SquareAvatar({
    super.key,
    required this.size,
    required this.backgroundImage,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        image: DecorationImage(
          image: backgroundImage,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
