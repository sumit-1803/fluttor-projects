import 'package:flutter/material.dart';

class More extends StatelessWidget {
  const More({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: Image.asset('assets/netflix_logo0.png'),
          title: const Padding(
            padding: EdgeInsets.only(right: 20),
            child: Text(
              'My List',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
          ),
          backgroundColor: Colors.black,
          actions: const [
            Padding(
              padding: EdgeInsets.only(right: 18),
              child: Icon(Icons.edit),
            )
          ],
        ),
        body: Container(
          color: Colors.black, // Set the background color to black
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Spacer(), // Add a Spacer to push "sort by" to the left
                ],
              ),
              const SizedBox(height: 5),
              const Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 10, right: 2),
                    child: Text(
                      "Suggestions",
                      style: TextStyle(
                          fontSize: 25,
                          color: Colors.white,
                          fontWeight:
                              FontWeight.bold), // Set text color to white
                      textAlign: TextAlign.start,
                    ),
                  ),
                  Icon(
                    Icons.arrow_drop_down,
                    color: Colors.white,
                    size: 40,
                  ), // Set icon color to white
                ],
              ),
              const SizedBox(height: 5),

              // first list

              Container(
                width: double.infinity,
                height: 100,
                color: Colors.black,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Image.asset(
                        'assets/orignal (1).jpeg', 
                        width: 100,
                        height: 100,
                      ),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Text(
                      'Daredevil',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Padding(
                      padding: EdgeInsets.only(left: 150),
                      child:
                          Icon(Icons.play_arrow_rounded, color: Colors.white),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),

              Container(
                width: double.infinity,
                height: 100,
                color: Colors.black,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Image.asset(
                        'assets/orignal (2).jpeg',
                        width: 100,
                        height: 100,
                      ),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Text(
                      'Sabrina',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Padding(
                      padding: EdgeInsets.only(left: 170),
                      child:
                          Icon(Icons.play_arrow_rounded, color: Colors.white),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),


              Container(
                width: double.infinity,
                height: 100,
                color: Colors.black,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    // Add an Image
                    Padding(
                      padding: const EdgeInsets.only(left: 0),
                      child: Image.asset(
                        'assets/orignal (3).jpeg', 
                        width: 100,
                        height: 100,
                      ),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Text(
                      'Vampire Diaries',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Padding(
                      padding: EdgeInsets.only(left: 100),
                      child:
                          Icon(Icons.play_arrow_rounded, color: Colors.white),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Container(
                width: double.infinity,
                height: 100,
                color: Colors.black,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                   
                    Padding(
                      padding: const EdgeInsets.only(right: 18),
                      child: Image.asset(
                        'assets/orignal (4).jpeg', 
                        width: 100,
                        height: 100,
                      ),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Text(
                      'Lucifer',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    
                    const SizedBox(width: 5),
                    
                    const Padding(
                      padding: EdgeInsets.only(left: 160),
                      child:
                          Icon(Icons.play_arrow_rounded, color: Colors.white),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                height: 20,
              ),
              Container(
                width: double.infinity,
                height: 100,
                color: Colors.black,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    
                    Padding(
                      padding: const EdgeInsets.only(right: 38),
                      child: Image.asset(
                        'assets/orignal (8).jpeg', 
                        width: 100,
                        height: 100,
                      ),
                    ),
                   
                    const SizedBox(width: 3),
                  
                    const Text(
                      'You',
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    
                    const SizedBox(width: 5),
                   
                    const Padding(
                      padding: EdgeInsets.only(left: 170),
                      child:
                          Icon(Icons.play_arrow_rounded, color: Colors.white),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
