import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
      theme: ThemeData.light(),
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: const Text("Youtube"),
          centerTitle: true,
          leading: Image.asset("assets/channels4_profile.jpg"),
          //leading: const Icon(Icons.battery_1_bar),
          actions: const [
            Icon(Icons.search),
            SizedBox(width: 10),
            Icon(Icons.video_call),
            SizedBox(width: 10),
            Icon(Icons.add),
            SizedBox(width: 10),
            Icon(Icons.account_circle)
          ],
        ),
        body: Column(
          children: [
            const SizedBox(
              height: 15,
            ),
            Container(
                width: 350,
                height: 300,
                decoration: BoxDecoration(
                    color: Colors.purple,
                    borderRadius: BorderRadius.circular(10))),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    height: 160,
                    width: 160,
                    decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(10))),
                const SizedBox(width: 20),
                Column(
                  children: [
                    Container(
                        width: 170,
                        height: 30,
                        decoration: BoxDecoration(
                            color: Colors.blue,
                            borderRadius: BorderRadius.circular(10))),
                    const SizedBox(
                      height: 5,
                    ),
                    Container(
                        width: 170,
                        height: 125,
                        decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(10)))
                  ],
                )
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
                height: 130,
                width: 350,
                decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(10)))
          ],
        ),
      )));
}