// import 'package:flutter/material.dart';

// class COUNTER extends StatefulWidget {
//   const COUNTER({super.key});

//   @override
//   State<COUNTER> createState() => _COUNTERState();
// }

// class _COUNTERState extends State<COUNTER> {
//   int count = 0;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       floatingActionButton: FloatingActionButton(onPressed:(){
//         count++;
//         print("this is current val of count $count");
//       }, 
//       child: const Text("ADD")
//       ),
//       body: Container(
//         //width: 400
//         width: MediaQuery.of(context).size.width,
//         color: Colors.lightGreen,
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Text("THIS IS COUNT"),
//             Text("COUNT: ${count.toString()}")
//           ],
//           Iconbutton(Color: colors.yellow)
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';

class COUNTER extends StatefulWidget {
  const COUNTER({super.key});

  @override
  State<COUNTER> createState() => _COUNTERState();
}

class _COUNTERState extends State<COUNTER> {
  int count = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            count++;
            setState(() {
              //
            });
          },
          child: const Text("ADD"),
        ),
        body: Container(
          color: Colors.green,
          width: MediaQuery.of(context).size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "This is the Count",
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
              Text("COUNT: ${count.toString()}",
                  style: const TextStyle(fontSize: 20, color: Colors.white)),
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    icon: const Icon(Icons.add, size: 30),
                    onPressed: () {
                      count++;
                      setState(() {
                        //
                      });
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.remove, size: 30),
                    onPressed: () {
                      count--;
                      setState(() {
                        //
                      });
                    },
                  ),
                ],
              )
            ],
          ),
        ));
  }
}