import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: Image.asset("assets/channels4_profile.jpg"),
          title: const Text(
            'YouTube',
          ),
          actions: const [
            Icon(Icons.cast),
            SizedBox(
              width: 20,
            ),
            SizedBox(
              width: 20,
            ),
            Icon(Icons.video_call),
            SizedBox(
              width: 20,
            ),
            Icon(Icons.search),
            CircleAvatar(
              backgroundColor: Colors.white,
            )
          ],
        ),
        body: Center(
          child: Column(
            children: [
              Container(
                width: 200,
                height: 200,
                decoration: const BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                child: Image.asset("assets/channels4_profile.jpg"),
              ),
              Container(
                width: 200,
                height: 200,
                decoration: const BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                child: Image.asset("assets/channels4_profile.jpg"),
              ),
              Container(
                width: 200,
                height: 200,
                decoration: const BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                child: Image.asset("assets/channels4_profile.jpg"),
              ),
              const Text(
                "HELLO FLUTTER",
                style: TextStyle(fontSize: 50),
              ),
            ],
          ),
        )),
  ));
}
