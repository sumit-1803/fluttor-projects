import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
    home: Scaffold(
      body: Center(child: Column(
      children: [const SizedBox(
     height: 30
     ),
     itemcontainer(containerColor: Colors.green, textdata: "hello"),
     itemcontainer(),
      ],),
    ),
  ),
  ),);
}

Container itemcontainer(
  {Color? containerColor, String? textdata}
) {
  return Container(
     width: 350,
              height: 50,
              decoration:  BoxDecoration(
                  color: containerColor!,
                  borderRadius: const BorderRadius.all(Radius.circular(20))),
                  alignment: Alignment.center,
                  child: Text(textdata!,  style: const TextStyle(fontSize: 20, color: Colors.black),
                  textAlign: TextAlign.center,),
  );
}