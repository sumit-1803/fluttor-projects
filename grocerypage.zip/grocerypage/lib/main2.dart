//import 'package:flutter/material.dart';

// void main(){
//   runApp(MaterialApp(
//     home: Scaffold(
//       body: Center(child: Column(
//       children: [const SizedBox(
//      height: 30
//      ),
//     //  const row]
//     // )
//   ))
//   ));
// }
import 'package:flutter/material.dart';
import 'package:flutter_application_1/screens/secondpage.dart';

void main() => runApp(MaterialApp(
  home: COUNTER(),
));