import 'package:flutter/material.dart';

class itemContainer extends StatelessWidget {
  Color containerColor;
  String textData = "";
  double contHt;

  itemContainer(this.textData,
      {super.key, required this.containerColor, required this.contHt});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: contHt, //cHeight,
      width: 100,
      decoration: BoxDecoration(
          color: containerColor, //containerColor,
          border: Border.all(width: 2),
          // border: Border.all(width: 20),
          borderRadius: const BorderRadius.all(Radius.circular(20))),
      child: Center(
          child: Text(
        textData,
        style: const TextStyle(color: Colors.white),
      )),
    );
  }
}