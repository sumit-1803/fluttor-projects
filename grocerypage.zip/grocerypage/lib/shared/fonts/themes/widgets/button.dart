import 'package:flutter/material.dart';

class Mybutton extends StatelessWidget {
  IconData buttonIcon;
  const Mybutton({super.key, required this.buttonIcon});

  @override
  Widget build(BuildContext context) {
    return Iconbutton(onPressed:() {}, icon: Icon(buttonIcon));
  }
}