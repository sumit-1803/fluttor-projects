import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
    home: Scaffold(backgroundColor: const Color.fromARGB(255, 10, 88, 153),
    body: Center(child: Column(
      children: [const SizedBox(
     height: 30
     ),
     const Row(
      crossAxisAlignment: CrossAxisAlignment.start ,
      children: [
        SizedBox(width: 20),
        Text("Your Cart", style: TextStyle(fontSize:32, color: Colors.white, fontWeight: FontWeight.bold ),)
      ],
     ),
    // const Text("Your Cart", style: TextStyle(fontSize: 38, color: Colors.white),),
    const SizedBox(
      height: 25,
    ), 
    Container(
       width: 350,
                height: 50,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(50))),
                    alignment: Alignment.center,
                    child: const Text("Delivery to Street No. 80 South City", style: TextStyle(fontSize: 20, color: Colors.black),
                    textAlign: TextAlign.center,),
    ),
    const SizedBox(
      height: 25,
    ),
    Container(
      width: 350,
      height: 140,
      decoration: const BoxDecoration(
       color: Colors.white,
       borderRadius: BorderRadius.all(Radius.circular(30)) 
      ),
      alignment: Alignment.centerLeft,
      child: const Row(
        children: [
        Image(width: 100,height: 160, image: AssetImage("assets/cucumber.jpeg")),
        SizedBox(width: 130, height: 20),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Text("Cucumber", style: TextStyle( fontWeight: FontWeight.bold, fontSize: 20),
             ),
             SizedBox(height: 10),
             Text("\$2.0"),
             SizedBox(height: 10),
             Text("\$2.0 (2kg)"),
             SizedBox(height: 10),
             Row(children: [
              Icon(
                Icons.add_circle,
                color: Color.fromARGB(255, 241, 224, 71),
              ),
              SizedBox(width: 5),
              Text("1"),
              SizedBox(width: 5),
              Icon(
                Icons.remove_circle,
                color: Color.fromARGB(255, 228, 211, 52),
              ),
             ],
             )
          ],
        )
      ],),
    ),

    const SizedBox(height: 25),

    Container(
      width: 350,
      height: 140,
      decoration: const BoxDecoration(
       color: Colors.white,
       borderRadius: BorderRadius.all(Radius.circular(30)) 
      ),
      alignment: Alignment.centerLeft,
      child: const Row(children: [
        Image(width: 100,height: 160, image: AssetImage("assets/banana.png")),
        SizedBox(width: 130, height: 20),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Text("Banana", style: TextStyle( fontWeight: FontWeight.bold, fontSize: 20),
             ),
             SizedBox(height: 10),
             Text("\$5.0"),
             SizedBox(height: 10),
             Text("\$5.0 (2kg)"),
             SizedBox(height: 10),
             Row(children: [
              Icon(
                Icons.add_circle,
                color: Color.fromARGB(255, 241, 224, 71),
              ),
              SizedBox(width: 5),
              Text("1"),
              SizedBox(width: 5),
              Icon(
                Icons.remove_circle,
                color: Color.fromARGB(255, 228, 211, 52),
              ),
             ],
             )
          ],
        )
      ],),
    ),
    const SizedBox(
      height: 25),

      Container(
      width: 350,
      height: 140,
      decoration: const BoxDecoration(
       color: Colors.white,
       borderRadius: BorderRadius.all(Radius.circular(30)) 
      ),
      alignment: Alignment.centerLeft,
      child: const Row(children: [
        Image(width: 100,height: 160, image: AssetImage("assets/chilli.jpeg")),
        SizedBox(width: 130, height: 20),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Text("Paprica", style: TextStyle( fontWeight: FontWeight.bold, fontSize: 20),
             ),
             SizedBox(height: 10),
             Text("\$2.5"),
             SizedBox(height: 10),
             Text("\$2.5 (1kg)"),
             SizedBox(height: 10),
             Row(children: [
              Icon(
                Icons.add_circle,
                color: Color.fromARGB(255, 241, 224, 71),
              ),
              SizedBox(width: 5),
              Text("1"),
              SizedBox(width: 5),
              Icon(
                Icons.remove_circle,
                color: Color.fromARGB(255, 228, 211, 52),
              ),
             ],
             )
          ],
        )
      ],),
    ),
    const SizedBox(
      height: 25),

     Container(
      width: 350,
      height: 80,
      decoration: const BoxDecoration(
       color: Colors.yellow,
       borderRadius: BorderRadius.all(Radius.circular(30)) 
      ),
      alignment: Alignment.center,
      child: const Text("Order Now", style: TextStyle(fontSize:25, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
     )
    ],),))
  ));
}