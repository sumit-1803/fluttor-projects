import 'package:dio/dio.dart';

class NewsClient {
  Dio _dio = Dio();

  getNewsDataFromAPI() async {
    String newsURL =
        'https://newsapi.org/v2/top-headlines?country=in&apiKey=f260fb0b62984346a1de00671e998536';
    try {
      var response = await _dio.get(newsURL);
      print('This is the news data from API ${response.data}');
      return response.data;
    } catch (error) {
      print('Error in fetching data form API');
    }
  }
}
