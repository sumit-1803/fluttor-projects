import 'package:flutter/material.dart';
import 'package:ted_app/screens/frontpage.dart';

void main() => runApp(MaterialApp(
      home: Front(),
    ));
